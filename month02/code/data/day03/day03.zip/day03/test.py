def a():
    s = 1
    s += 1
    print(s)
    a()

a()