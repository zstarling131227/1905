from ydmapi import *

result = get_result('ydm4.jfif')
print(result)