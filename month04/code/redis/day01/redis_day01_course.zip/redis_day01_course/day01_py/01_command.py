import redis

# 创建连接对象
r = redis.Redis(host="127.0.0.1",port=6379,db=0)

# 通用命令示例
# 列表
key_list = r.keys('*')
for key in key_list:
    # print(key.decode())
    pass

# b'list'
print(r.type('mylist'))
# 返回值: 0 | 1
print(r.exists('mylist'))
# 设置过期时间
r.expire('mylist',5)
# 删除key
r.delete('mylist2','mylist3')
print('mylist2,mylist3 删除成功')
























