import redis

r = redis.Redis(host='127.0.0.1',port=6379,db=0)

# 常见服务端口号
# 1. mysql -> 3306
# 2. mongodb -> 27017
# 3. redis -> 6379
# 4. http  -> 80
# 5. https -> 443
# 6. ssh   -> 22  远程连接服务
# 7. telnet-> 23  远程连接服务
# 8. ftp   -> 21

# 列表操作
# ['LaoQi','Maria','LaoGuo','ChaoGeGe']
r.rpush('tedu:teachers','LaoQi','Maria','LaoGuo')
r.rpush('tedu:teachers','ChaoGeGe')
# 在Maria的后面加上 LaoTao
r.linsert("tedu:teachers",'after','Maria','LaoTao')
# 打印长度
print(r.llen('tedu:teachers'))
# 查看所有元素 - 列表
print(r.lrange('tedu:teachers',0,-1))
# 弹出1个元素
print(r.rpop('tedu:teachers'))
# 保留指定范围内元素
r.ltrim('tedu:teachers',0,2)
# 阻塞弹出
while True:
    # result: (b'tedu:teachers', b'LaoTao')
    # 3秒后无元素弹出,返回None
    result = r.brpop('tedu:teachers',3)
    if result:
        print(result)
    else:
        break

r.expire('tedu:teachers',10)




































