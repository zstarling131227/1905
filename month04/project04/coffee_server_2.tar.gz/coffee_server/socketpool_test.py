# socketpool通用连接池测试
import socketpool
