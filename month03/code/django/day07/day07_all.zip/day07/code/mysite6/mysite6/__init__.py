
# file: mysite5/__init__.py
import pymysql

pymysql.install_as_MySQLdb()