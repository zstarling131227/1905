from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.http import Http404

def index_view(request):
    print("主页被访问！")
    return HttpResponse("主页")

def page1_view(request):
    print("40444444444444444444444")
    raise Http404
    # return HttpResponse("页面1")
