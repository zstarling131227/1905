from django.apps import AppConfig


class Bookstore2Config(AppConfig):
    name = 'bookstore2'
