from django.apps import AppConfig


class Bookstore3Config(AppConfig):
    name = 'bookstore3'
