from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from .models import User


def xhr(request):

    return render(request, 'xhr.html')

def get_xhr(request):

    return render(request, 'get-xhr.html')


def get_xhr_server(request):
    if request.GET.get('uname'):
        uname = request.GET['uname']
        return HttpResponse('welcome  %s'%(uname))
    return HttpResponse('This is ajax request !')

def register(request):
    return render(request, 'register.html')

def checkuname(request):
    #1　获取ajax传过来的用户名
    uname = request.GET.get('uname')
    #2 校验用户名是否存在
    users = User.objects.filter(uname=uname)
    if users:
        return HttpResponse('用户名已存在')
    return HttpResponse('ok')

def make_post(request):
    if request.method == 'GET':
        return render(request, 'make_post.html')
    elif request.method == 'POST':
        #获取表单数据
        uname = request.POST.get('uname')
        pwd = request.POST.get('pwd')
        return HttpResponse('Your post is ok  %s %s !!!'%(uname, pwd))
    else:
        raise














































