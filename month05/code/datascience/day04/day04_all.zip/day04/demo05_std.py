# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo05_std.py  中位数
"""
import numpy as np
import datetime as dt
import matplotlib.pyplot as mp
import matplotlib.dates as md


def dmy2ymd(dmy):
    dmy = str(dmy, encoding='utf-8')
    time = dt.datetime.strptime(dmy, '%d-%m-%Y')
    t = time.date().strftime('%Y-%m-%d')
    return t

dates, opening_prices, highest_prices, \
    lowest_prices, closing_prices, volumes = \
    np.loadtxt(
        '../da_data/aapl.csv', delimiter=',',
        usecols=(1, 3, 4, 5, 6, 7), unpack=True,
        dtype='M8[D], f8, f8, f8, f8, f8',
        converters={1: dmy2ymd})

# 标准差
std = np.std(closing_prices)
print(std)

m = closing_prices.mean()
d = (closing_prices - m)**2
v = np.mean(d)
s = np.sqrt(v)
print(s)
