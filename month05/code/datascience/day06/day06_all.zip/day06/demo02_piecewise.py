# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo02_piecewise.py  数组处理函数
"""
import numpy as np
import matplotlib.pyplot as mp

a = np.array([-7, 8, 15, 0, -5])
# 模拟np.sign()函数
r = np.piecewise(a, [a < 0, a == 0, a > 0],
                 [-1, 0, 1])
print(r)
print(np.sign(a))
