# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""
demo05_matrix.py  矩阵
"""
import numpy as np
ary = np.arange(1, 10).reshape(3, 3)
m = np.matrix(ary, copy=True)
print(m, type(m))
ary[0, 0] = 999
print(m, type(m))

m2 = np.mat(m)
print(m2)

# 测试数据拼块规则
m3 = np.mat('1 2 1; 4 7    6; 5,3,1')
print(m3, type(m3))

print('-' * 45)

# 测试矩阵的乘法运算规则
a = np.arange(1, 10).reshape(3, 3)
print(a * a)  # 数组相乘
print(np.mat(a) * np.mat(a))  # 矩阵相乘
print('-' * 45)

# 获取A矩阵的逆矩阵
a = np.mat('1 2 3; 4 5 6; 7 8 9')
a = np.mat('1 4 7; 5 6 2')
print(a)
print(a.I)
print(a * a.I)
# print(np.linalg.inv(a))  #仅适用于方阵
print('-' * 45)

# 应用题 解方程组
A = np.mat('3 3.2; 3.5 3.6')
B = np.mat('118.4; 135.2')
# 求误差最小的一组结果
# x = np.linalg.lstsq(A, B)[0]
x = np.linalg.solve(A, B)  # 求唯一解
print(x)

persons = A.I * B
print(persons)

print(A ** 0)
