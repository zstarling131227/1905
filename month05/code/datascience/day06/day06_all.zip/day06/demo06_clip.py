# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo06_clip.py   数组通用函数
"""
import numpy as np

a = np.arange(1, 10).reshape(3, 3)
print(a)
print(a.clip(min=3, max=6))

# compress
a = np.arange(100)
# print(a.compress((a % 3 == 0) and (a % 7 == 0)))
r = a.compress(np.all(
    [a % 3 == 0, a % 7 == 0], axis=0))
print(r)
