# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo03_vec.py  函数矢量化
"""
import numpy as np
import math as m


def foo(x, y):
    return m.sqrt(x**2 + y**2)

a, b = 3, 4
a = np.arange(3, 9).reshape(2, 3)
b = np.arange(4, 10).reshape(2, 3)
print('a:', a)
print('b:', b)
# print(foo(a, b))
# 矢量化处理foo函数，使之可以处理矢量数据
foo_vec = np.vectorize(foo)
print(foo_vec(a, b))

# 使用frompyfunc函数矢量化处理该函数
foo_fpf = np.frompyfunc(foo, 2, 1)
print(foo_fpf(a, b))
