# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo04_profit.py  定义投资策略，拿历史数据进行验证
"""
import numpy as np
import datetime as dt
import matplotlib.pyplot as mp
import matplotlib.dates as md


def dmy2ymd(dmy):
    dmy = str(dmy, encoding='utf-8')
    time = dt.datetime.strptime(dmy, '%d-%m-%Y')
    t = time.date().strftime('%Y-%m-%d')
    return t

dates, opening_prices, highest_prices, \
    lowest_prices, closing_prices = np.loadtxt(
        '../da_data/aapl.csv', delimiter=',',
        usecols=(1, 3, 4, 5, 6), unpack=True,
        dtype='M8[D], f8, f8, f8, f8',
        converters={1: dmy2ymd})

# 绘制收盘价折线图
mp.figure('AAPL Profit', facecolor='lightgray')
mp.title('AAPL Profit', fontsize=16)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.tick_params(labelsize=10)
mp.grid(linestyle=':')
# 设置x轴刻度定位器
ax = mp.gca()
ax.xaxis.set_major_locator(
    md.WeekdayLocator(byweekday=md.MO))
ax.xaxis.set_major_formatter(
    md.DateFormatter('%d %b %Y'))
ax.xaxis.set_minor_locator(md.DayLocator())

# 为了日期显示合理，修改dates的dtype
dates = dates.astype(md.datetime.datetime)


def profit(opening_price, highest_price,
           lowest_price, closing_price):
    # 定义买入卖出策略，通过开高低收计算当天收益
    # 如果低于开盘价0.01则买入，收盘价时卖出
    buying_price = opening_price * 0.99
    if lowest_price <= buying_price <= highest_price:
        return (closing_price - buying_price)\
            / buying_price
    return np.nan  # 当天没交易

# 矢量化profit函数，计算每天的收益
profits = np.vectorize(profit)(
    opening_prices, highest_prices,
    lowest_prices, closing_prices)
nan_mask = np.isnan(profits)
print(~nan_mask)
# 绘制收益曲线
mp.plot(dates[~nan_mask], profits[~nan_mask],
        'o-', color='dodgerblue',
        label='Profits')
print(profits[~nan_mask].mean())

mp.legend()
mp.gcf().autofmt_xdate()
mp.show()
