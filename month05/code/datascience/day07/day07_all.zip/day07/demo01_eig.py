# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo01_eig.py   特征值提取
"""
import numpy as np

A = np.mat('1 6 3 7;3 8 4 6;1 4 9 5;6 8 3 5')
print(A)
# 提取特征值
eigvals, eigvecs = np.linalg.eig(A)
print(eigvals, '---eigvals')
print(eigvecs, '---eigvecs')

# 逆向推导原矩阵
eigvals[1:] = 0
A2 = eigvecs * np.diag(eigvals) * eigvecs.I
print(A2)
