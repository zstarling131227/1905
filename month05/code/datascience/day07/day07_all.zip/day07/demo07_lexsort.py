# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo07_lexsort.py  联合间接排序
"""
import numpy as np

names = np.array(
    ['Huawei', 'Apple', 'Mi', 'Oppo', 'Vivo'])
prices = [4999, 8888, 2999, 3999, 3999]
volumes = np.array([80, 3, 45, 30, 35])

# 先按price，再按volumes排序
indices = np.lexsort((volumes, prices))
print(names[indices])
# 按volumes倒序排序
indices = np.lexsort((-volumes, prices))
print(names[indices])


#             0  1  2  3  4  5  6
a = np.array([1, 2, 4, 5, 6, 8, 9])
b = np.array([7, 3])
c = np.searchsorted(a, b)
print(c)
d = np.insert(a, c, b)
print(d)
