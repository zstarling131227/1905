# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo08_interp.py  插值
"""
import numpy as np
import scipy.interpolate as si
import matplotlib.pyplot as mp

# 找一组散列点坐标
min_x = -50
max_x = 50
dis_x = np.linspace(min_x, max_x, 15)
dis_y = np.sinc(dis_x)
mp.scatter(dis_x, dis_y, marker='D', s=60)

# 使用插值，使散列的点连续化
linear = si.interp1d(dis_x, dis_y, kind='linear')
x = np.linspace(min_x, max_x, 1000)
y = linear(x)
mp.plot(x, y, label='linear', alpha=0.3)

# 三次样条插值
cubic = si.interp1d(dis_x, dis_y, kind='cubic')
x = np.linspace(min_x, max_x, 1000)
y = cubic(x)
mp.plot(x, y, label='cubic')

mp.show()
