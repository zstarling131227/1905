# -*- coding: utf-8 -*-
from __future__ import unicode_literals
'''
demo01_ndarray.py
'''
import numpy as np

ary = np.array([1, 2, 3, 4, 5])
print(ary, type(ary))
print(ary * 10)
print(ary + ary)
