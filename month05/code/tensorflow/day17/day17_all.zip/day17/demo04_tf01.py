# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo04_tf01.py  tensorflow演示
"""
import tensorflow as tf
