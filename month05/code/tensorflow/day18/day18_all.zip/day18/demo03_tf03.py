# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo03_tf03.py   feed数据
"""
import tensorflow as tf

with tf.Session() as sess:
    x = tf.placeholder(tf.float32, shape=(1, 2))
    y = x + x
    r = sess.run(y, feed_dict={x: [[3.0, 4.0]]})
    print(r)

    x2 = tf.placeholder(tf.float32, shape=(None, 2))
    y = tf.reduce_sum(x2, 0)
    r = sess.run(y, feed_dict={
        x2: [[3.0, 4.0], [1.2, 2.3], [1.0, 2.0]]})
    print(r)
