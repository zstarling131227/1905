# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import tensorflow as tf

# 创建两个Variable对象
bias = tf.Variable(tf.zeros(200), name='bias')
w = tf.Variable(tf.random_normal(
    (784, 200), stddev=0.35, mean=0, seed=1))
print(bias)
print(w)

# 变量初始化
initop = tf.initialize_all_variables()

with tf.Session() as sess:
    sess.run(initop)
    print(sess.run(w))
