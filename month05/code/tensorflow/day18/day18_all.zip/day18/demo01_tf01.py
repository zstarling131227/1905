# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo01_tf01.py  tensorflow演示
"""
import tensorflow as tf

a = tf.constant([1.0, 2.0], name='a')
b = tf.constant([2.0, 3.0], name='b')
ab = a + b
result = tf.add(a, ab)
print(result)

with tf.Session() as sess:
    r = sess.run(result)
    print(r)
