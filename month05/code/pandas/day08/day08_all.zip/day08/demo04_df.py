# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo04_df.py  DataFrame对象
"""
import pandas as pd
import numpy as np

data = [['Alex', 10], ['Tom', 12], ['Jerry', 13]]
# 通过二维数组创建DataFrame对象
df = pd.DataFrame(data)
print(df)

# 指定columns: 列名
df = pd.DataFrame(data, columns=['Name', 'Age'])
print(df)
print(df.dtypes)  # 访问元素数据类型

# 指定dtype: 元素类型
df = pd.DataFrame(
    data, columns=['Name', 'Age'], dtype=float)
print(df)
print(df.dtypes)  # 访问元素数据类型

# 通过字典的方式创建DataFrame对象
# 字典的key表示列名， value表示当列值的列表
data = {'Name': ['Tom', 'Jerry', 'Bob'],
        'Age': [12, 13, 14]}
df = pd.DataFrame(data)
print(df)

# 构建DataFrame对象的同时指定行标（index）
df = pd.DataFrame(data, index=['A', 'B', 'C'])
print(df)
df = pd.DataFrame(
    data, index=pd.date_range(
        '2019-01-01', periods=3))
print(df)

# 其他情况   （每个字段一行记录）
data = [{'a': 1, 'b': 2},
        {'a': 5, 'b': 10, 'c': 20}]
df = pd.DataFrame(data)
print(df)


data = {'one': pd.Series([1, 2, 3], index=['a', 'b', 'c']),
        'two': pd.Series(
    [1, 2, 3, 4], index=['a', 'b', 'c', 'd'])}
df = pd.DataFrame(data)
print(df)

# 列访问
print(df['one'], type(df['one']))  # 单列
print('-' * 45)
print(df[['one', 'two']])  # 多列

# 列添加
data = {'Name': ['Tom', 'Jack', 'Steve', 'Ricky'],
        'Age': [28, 34, 29, 42]}
df = pd.DataFrame(data, index=['A', 'B', 'C', 'D'])
print(df)
df['score'] = pd.Series(
    [90, 80, 70, 60], index=['A', 'B', 'C', 'D'])
print(df)


# 列删除
d = {'one': pd.Series([1, 2, 3], index=['a', 'b', 'c']), 'two': pd.Series([1, 2, 3, 4], index=[
    'a', 'b', 'c', 'd']), 'three': pd.Series([10, 20, 30], index=['a', 'b', 'c'])}
df = pd.DataFrame(d)
print("dataframe is:")
print(df)

# 删除一列： one
del(df['one'])
print(df)

# 调用pop方法删除一列
df.pop('two')
print(df)


# 行访问
print('-' * 45)
d = {'one': pd.Series([1, 2, 3], index=['a', 'b', 'c']), 'two': pd.Series(
    [1, 2, 3, 4], index=['a', 'b', 'c', 'd'])}

df = pd.DataFrame(d)
print(df[2:4])

# loc方法通过行名获取数据
print('-' * 45)
print(df.loc['b'], type(df.loc['b']))
print(df.loc[['a', 'b']])

# iloc方法通过下标访问行数据
print('-' * 45)
print(df.iloc[2])
print(df.iloc[[2, 3]])


# 行添加
df = pd.DataFrame([['zs', 12], ['ls', 4]], columns=['Name', 'Age'])
df2 = pd.DataFrame([['ww', 16], ['zl', 8]], columns=['Name', 'Age'])
df = df.append(df2)
print(df)
# s = pd.Series(['tq', 7], index=['Name', 'Age'])
# df = df.append(s)
# print(df)

print('-' * 45)
df = df.drop(0)
print(df)

#  修改元素
print('-' * 45)
df = pd.DataFrame([['zs', 12], ['ls', 4]], columns=['Name', 'Age'])
df2 = pd.DataFrame([['ww', 16], ['zl', 8]], columns=['Name', 'Age'])
df = df.append(df2)
df['Name'][0] = 'Tom'
print(df)
