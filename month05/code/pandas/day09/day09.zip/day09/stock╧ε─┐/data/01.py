import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# date         2019-06-28
# open         3.19
# high         3.47
# close        3.47
# low          3.19
# volume       570919
# price_change 0.32
# p_change     10.16
# ma5          3.236
# ma10         3.204
# ma20         3.195
# v_ma5        156839.68
# v_ma10       109385.03
# v_ma20       88081.98


        
class stockforecast(object):

    
    
    def __init__(self):
        '''
        K_data.csv 文件名
        delimiter 分隔符
        usecols 使用的列序号，从0开始
        unpack 设置返回列
        '''
        self.date,self.opening_price, self.closing_price, self.volume, self.diff, self.ma5 = np.loadtxt(
            'K_data.csv',
            delimiter=',',
            usecols=(0, 1, 3, 5, 6, 8),
            dtype='M8[D], f8, f8, f8, f8, f8,',
            unpack=True
        )

    # 最小二乘多项式拟合
    def linearregression(self, date, valdata):
        # 讲日期类型转为int
        days = date.astype(int)
        p = np.polyfit(days, valdata, 4)
        # 预测未来一天数据
        date_fea = np.zeros((1, ))
        num = days[0] + 1
        date_fea[0, ] = num
        return np.polyval(p, date_fea)
    
    # 布林带
    '''
    中规往往是一条中期均线
    上轨和下轨分别是中轨加上或减去同期收盘价的标准差固定的倍数，标准版为2倍
    '''
    def boll(self, date, ma5, closing_price):
        # 求标准差
        stds = np.zeros(ma5.size - 5)
        for i in range(0, stds.size):
            # print(stds.shape)
            stds[i] = closing_price[i:i + 5,].std()
        stds *= 2
        lower = ma5[:stds.size,] - stds
        upper = ma5[:stds.size,] + stds
        return self.linearregression(date, lower), self.linearregression(date, upper), lower, upper

    # OBV
    def obv(self, diff, volume):
        return diff * volume
        
    # 多项式线性拟合
    def line(self, x, y, t):
        #调用线性规划包
        model = LinearRegression()
        #线性回归训练
        model.fit(x, y)
        #截距
        a = model.intercept_
        #回归系数
        b = model.coef_
        print("拟合参数:截距",a,",回归系数：",b)
        Y_pred = model.predict(t)
        print('今日收盘价',y[0, 0], '预测明日收盘价',Y_pred[0, 0])
        plt.plot(y)
        plt.plot(Y_pred, c='red')
        plt.show()
        if y[0, 0] > Y_pred[0, 0]:
            return '建议卖出'
        elif y[0, 0] <= Y_pred[0, 0]:
            return '建议买入'
        

    def main(self):
        date, opening_price, closing_price, volume, diff, ma5 = \
            self.date, self.opening_price, self.closing_price, self.volume, self.diff, self.ma5
        # 预测后一天的开盘价，ma5,布林下线，布林上线，obv
        preopen = self.linearregression(date, opening_price)
        prema5 = self.linearregression(date, ma5)
        prelower, preupper, lower, upper = self.boll(date[:-5], ma5, closing_price)
        obvs = self.obv(diff, volume)
        preobv = self.linearregression(date, obvs)
        x = np.array([opening_price[:-5], ma5[:-5], lower, upper, obvs[:-5]]).T
        y = np.array([closing_price[:-5]],).T
        t = np.array([preopen, prema5, prelower, preupper, preobv]).T
        return self.line(x, y, t)

callback = stockforecast()
print(callback.main())
